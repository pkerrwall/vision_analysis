# CeleST
CeleST - C. elegans Swim Test

##Tested Specifications:
Matlab 2015b

Mac OSX 10.8 Mountain Lion and later
